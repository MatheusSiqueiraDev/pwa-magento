# Hibrido News API
Utilizando as APIs do https://newsapi.org/, crie um módulo que mostre as principais notícias do TechCrunch em um Widget que possa ser criado e colocado em qualquer página.

Widgets, Models, Template PHTML

- [X] 2.1. Criando os arquivos necessários de um novo módulo e habilitando o mesmo
- [X] 2.2. Criando um novo widget (XML)
- [X] 2.3. Criando uma classe que comunique com a API
- [X] 2.4. Criando o template do widget
- [X] 2.5. Criando o novo widget no painel e mostrando ele na Home


## TO-DO

- [X] Extrair o token e colocar na config
- [X] Colocar as sources na config (buscando direto da API de sources)
- Colocar um limite nas configs também
- [X] Adicionar as configs no admin (system xml + acl xml) no menu de services
- [X] Implementar um Logger em arquivo diferente utilizando os virtual types
- [X] Estilizar as noticias
- [X] Colocar em widget
- [X] Colocar um slider ou paginação
- [X] Colocar em Knockout JS
- Fazer uma web api para retornar as noticias (RepositoryInterface)
- Quando trocar qualquer config do módulo limpar o cache de front
- Botão para dar like e deslike na noticia
- Botão para salvar a noticia para ler depois (logado)
- Refatorar as classes para deixar mais condizente com a arquitetura escolhida
- [1/2] Colocar um cache nas chamadas da API, dividir em duas classes (uma de articles e uma de sources) deixando o connector apenas retornar o body da response (ficando mais fácil de cachear)
- Resolver o bug de quando não temos um token (ele não mostra a página de config, porque depende do token para buscar as sources)

## Dúvidas

- Como colocar as fontes apenas nas páginas que o widget for chamado?
