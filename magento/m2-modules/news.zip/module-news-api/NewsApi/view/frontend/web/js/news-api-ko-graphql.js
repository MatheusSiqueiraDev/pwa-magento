/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'ko',
    'uiComponent',
    'mage/storage'
], function (ko, Component, storage) {

    return Component.extend({

        defaults: {
            template: 'Hibrido_NewsApi/news-api-ko-graphql',
            searchQuery: ko.observable('').extend({ rateLimit: 500 }),
            news: []
        },

        initialize: function () {
            this._super();
            this.observe(['news']);
            this.getNewsFromGraphQl();
        },

        getNewsFromGraphQl: function () {
            const query = `
            query getArticles($title: String)
            {
                articles(title: $title) {
                    url
                    title
                    image
                    description
                }
            }`;

            const variables = {
                title: this.searchQuery()
            };

            storage.post(
                'graphql',
                JSON.stringify({ query, variables })
            ).done(({ data: { articles } }) => {
                this.news([]);
                articles.forEach((item) => this.news.push(item));
            });
        },

        addTesteNews: function () {
            this.news.unshift({
                "title": "Teste 2",
                "url": "#",
                "description": "Teste Desc 2",
                "image": "#"
            });
        },
    });

});
