/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'uiComponent'
], function (Component) {

    return Component.extend({

        defaults: {
            template: "Hibrido_NewsApi/news-api-ko",
            news: []
        },

        initialize: function () {
            this._super();
            this.observe(['news']);
        },

        addTesteNews: function () {
            this.news.unshift({
                "title": "Teste 2",
                "url": "#",
                "description": "Teste Desc 2",
                "image": "#"
            });
        },
    });

});
