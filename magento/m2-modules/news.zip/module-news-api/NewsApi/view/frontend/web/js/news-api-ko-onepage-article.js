/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'uiComponent',
    'ko'
], function (Component, ko) {

    return Component.extend({

        defaults: {
            template: "Hibrido_NewsApi/news-api-ko-onepage-article",
            title: ko.observable(''),
            description: ko.observable(''),
            url: ko.observable(''),
            image: ko.observable('')
        }

    });

});