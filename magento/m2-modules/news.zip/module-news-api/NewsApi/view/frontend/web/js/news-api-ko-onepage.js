/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'uiComponent',
    'uiLayout',
    'uiRegistry',
    'underscore'
], function (Component, layout, registry, _) {

    function slugify(text)
    {
        return text
            .toLowerCase()
            .replace(/ /g,'-')
            .replace(/[^\w-]+/g,'');
    }

    return Component.extend({

        defaults: {
            template: "Hibrido_NewsApi/news-api-ko-onepage"
        },

        initialize (componentData) {
            this._super();

            if (typeof componentData.news !== 'undefined') {
                let articlesComponentsData = [];

                _.each(componentData.news, (article) => {
                    articlesComponentsData.push({
                        parent: this.name,
                        name: slugify(article.title),
                        displayArea: 'articlesDisplayArea',
                        component: 'Hibrido_NewsApi/js/news-api-ko-onepage-article',
                        config: article
                    });
                });

                layout(articlesComponentsData, this);
            }
        },

        addTesteNews () {
            let articleComponentData = {
                url: '#',
                image: '#',
                title: `Title Teste ${Math.random()}`,
                description: `Description Teste ${Math.random()}`
            };

            layout([
                {
                    parent: this.name,
                    name: slugify(articleComponentData.title),
                    displayArea: 'articlesDisplayAreaTeste',
                    component: 'Hibrido_NewsApi/js/news-api-ko-onepage-article',
                    config: articleComponentData
                }
            ], this);
        },

        removeArticle (article) {
            this.removeChild(slugify(article.title));
        }
    });

});