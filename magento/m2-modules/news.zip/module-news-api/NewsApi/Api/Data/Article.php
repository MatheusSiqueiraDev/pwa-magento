<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Api\Data;

/**
 * @api
 */
interface Article
{
    public function getUrl(): string;
    public function getImage(): string;
    public function getTitle(): string;
    public function getDescription(): string;
}
