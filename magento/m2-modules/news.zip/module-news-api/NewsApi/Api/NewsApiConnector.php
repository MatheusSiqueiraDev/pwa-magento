<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Api;

use Hibrido\NewsApi\Api\Data\Article;
use Hibrido\NewsApi\Api\Data\SourceInterface;
use Magento\Framework\Exception\LocalizedException;

/**
 * @api
 */
interface NewsApiConnector
{
    /**
     * @return Article[]
     * @throws LocalizedException
     */
    public function execute(): array;

    /**
     * @return SourceInterface[]
     * @throws LocalizedException
     */
    public function getSources(): array;
}
