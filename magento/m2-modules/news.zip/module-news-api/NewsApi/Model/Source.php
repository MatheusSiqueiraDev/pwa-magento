<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Model;

use Hibrido\NewsApi\Api\Data\SourceInterface;

class Source implements SourceInterface
{
    public function __construct(
        private readonly string $code,
        private readonly string $name
    ) {}

    public function getCode(): string
    {
        return $this->code;
    }

    public function getName(): string
    {
        return $this->name;
    }
}
