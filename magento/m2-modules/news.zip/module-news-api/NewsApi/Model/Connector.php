<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Model;

use Exception;
use Hibrido\NewsApi\Api\Data\Article;
use Hibrido\NewsApi\Api\Data\ArticleFactory;
use Hibrido\NewsApi\Api\Data\SourceInterface;
use Hibrido\NewsApi\Api\Data\SourceInterfaceFactory;
use Hibrido\NewsApi\Api\NewsApiConnector;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\HTTP\ClientFactory;
use Magento\Framework\HTTP\ClientInterface;
use Psr\Log\LoggerInterface;

class Connector implements NewsApiConnector
{
    public function __construct(
        private readonly ClientFactory $httpClientFactory,
        private readonly ArticleFactory $articleFactory,
        private readonly SourceInterfaceFactory $sourceInterfaceFactory,
        private readonly LoggerInterface $logger,
        private readonly Config $config
    ) {}

    /**
     * @inheritdoc
     */
    public function execute(): array
    {
        $client = $this->getHttpClient();

        try {
            $client->get($this->getArticlesUri());
        } catch (Exception $e) {
            $this->logger->info('News API Articles Fail Response.', [
                'exceptionCode' => $e->getCode(),
                'exceptionMessage' => $e->getMessage()
            ]);

            throw new LocalizedException(__($e->getMessage()));
        }

        return $this->processArticlesResponse($client);
    }

    /**
     * @inheritdoc
     */
    public function getSources(): array
    {
        $client = $this->getHttpClient();

        try {
            $client->get($this->getSourcesUri());
        } catch (Exception $e) {
            $this->logger->info('News API Sources Fail Response.', [
                'exceptionCode' => $e->getCode(),
                'exceptionMessage' => $e->getMessage()
            ]);

            throw new LocalizedException(__($e->getMessage()));
        }

        return $this->processSourcesResponse($client);
    }

    private function getHttpClient(): ClientInterface
    {
        $client = $this->httpClientFactory->create();
        $client->addHeader('Accept', 'application/json');
        $client->addHeader('Content-Type', 'application/json');
        $client->addHeader('User-Agent', 'Magento NewsApi Module');

        return $client;
    }

    /**
     * @token: 228244efb716464f905b675f7d8a773d
     */
    private function getArticlesUri(): string
    {
        return sprintf(
            $this->config->getUrl(),
            $this->config->getSources(),
            $this->config->getToken()
        );
    }

    private function getSourcesUri(): string
    {
        return sprintf(
            'https://newsapi.org/v2/top-headlines/sources?apiKey=%s',
            $this->config->getToken()
        );
    }

    /**
     * @return Article[]
     * @throws LocalizedException
     */
    private function processArticlesResponse(ClientInterface $client): array
    {
        $body = json_decode($client->getBody());

        if ($body->status !== 'ok') {
            $msg = __('News API Article Fail Response, status not "ok". ["code": %1 / "message": %2]', $body->code, $body->message);
            $this->logger->info($msg);
            throw new LocalizedException($msg);
        }

        $result = [];

        foreach ($body->articles as $article) {
            try {
                $result[] = $this->articleFactory->create([
                    'url' => $article->url,
                    'title' => $article->title,
                    'image' => $article->urlToImage,
                    'description' => $article->description
                ]);
            } catch (Exception $e) {
                $this->logger->info('News API to create News entity.', [
                    'exceptionCode' => $e->getCode(),
                    'exceptionMessage' => $e->getMessage()
                ]);

                continue;
            }
        }

        return $result;
    }

    /**
     * @return SourceInterface[]
     * @throws LocalizedException
     */
    private function processSourcesResponse(ClientInterface $client): array
    {
        $body = json_decode($client->getBody());

        if ($body->status !== 'ok') {
            $msg = __('News API Sources Fail Response, status not "ok". ["code": %1 / "message": %2]', $body->code, $body->message);
            $this->logger->info($msg);
            throw new LocalizedException($msg);
        }

        $result = [];

        foreach ($body->sources as $source) {
            try {
                $result[] = $this->sourceInterfaceFactory->create([
                    'code' => $source->id,
                    'name' => $source->name
                ]);
            } catch (Exception $e) {
                $this->logger->info('News API to create Source entity.', [
                    'exceptionCode' => $e->getCode(),
                    'exceptionMessage' => $e->getMessage()
                ]);

                continue;
            }
        }

        return $result;
    }
}
