<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Model;

use Hibrido\NewsApi\Api\Data\Article;

class News implements Article
{
    public function __construct(
        private readonly string $url,
        private readonly string $image,
        private readonly string $title,
        private readonly string $description
    ) {}

    public function getUrl(): string
    {
        return $this->url;
    }

    public function getImage(): string
    {
        return $this->image;
    }

    public function getTitle(): string
    {
        return $this->title;
    }

    public function getDescription(): string
    {
        return $this->description;
    }
}
