<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Model\Config\Source;

use Hibrido\NewsApi\Api\Data\SourceInterface;
use Hibrido\NewsApi\Api\NewsApiConnector;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\Exception\LocalizedException;

class Source implements OptionSourceInterface
{
    public function __construct(
        private readonly NewsApiConnector $newsApiConnector
    ) {}

    public function toOptionArray(): array
    {
        try {
            return array_map(function (SourceInterface $source) {
                return [
                    'value' => $source->getCode(),
                    'label' => $source->getName()
                ];
            }, $this->newsApiConnector->getSources());
        } catch (LocalizedException $e) {
            return [];
        }

    }
}
