<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Model;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class Config
{
    const XML_CONFIG_GENERAL_PATH = 'newsapi/general/';
    const XML_CONFIG_GENERAL_URL_PATH = self::XML_CONFIG_GENERAL_PATH . 'url';
    const XML_CONFIG_GENERAL_SOURCES_PATH = self::XML_CONFIG_GENERAL_PATH . 'sources';
    const XML_CONFIG_GENERAL_TOKEN_PATH = self::XML_CONFIG_GENERAL_PATH . 'token';

    public function __construct(
        private readonly ScopeConfigInterface $scopeConfig
    ) {}

    public function getUrl(): string
    {
        return $this->scopeConfig->getValue(self::XML_CONFIG_GENERAL_URL_PATH, ScopeInterface::SCOPE_STORE);
    }

    public function getSources(): string
    {
        return $this->scopeConfig->getValue(self::XML_CONFIG_GENERAL_SOURCES_PATH, ScopeInterface::SCOPE_STORE);
    }

    public function getToken(): string
    {
        return $this->scopeConfig->getValue(self::XML_CONFIG_GENERAL_TOKEN_PATH, ScopeInterface::SCOPE_STORE);
    }
}
