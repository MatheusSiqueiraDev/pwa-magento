<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Model\Connector;

use Hibrido\NewsApi\Api\NewsApiConnector;
use Magento\Framework\App\CacheInterface;

class ConnectorCacheDecorator implements NewsApiConnector
{
    const SOURCES_CACHE_KEY = 'sources';
    const ARTICLES_CACHE_KEY = 'articles';

    # Using PHP8 - Constructor Property Promotion
    public function __construct(
        private readonly NewsApiConnector $next,
        private readonly CacheInterface $cache
    ) {}

    /**
     * @inheritdoc
     */
    public function execute(): array
    {
        if ($result = $this->cache->load($this->getArticlesCacheKey())) {
            // @TODO: Deserializar com as classes do Magento
            return unserialize($result);
        }

        $result = $this->next->execute();

        # Using PHP8 - Named Arguments
        $this->cache->save(
            serialize($result),
            $this->getArticlesCacheKey(),
            lifeTime: 3600
        );

        return $result;
    }

    /**
     * @inheritdoc
     */
    public function getSources(): array
    {
        // @TODO: Add cache layer
        return $this->next->getSources();
    }

    private function getArticlesCacheKey(): string
    {
        // @TODO: To be continued ... store / sources / articles url (tudo ta nas configs)
        return static::ARTICLES_CACHE_KEY . '_';
    }
}
