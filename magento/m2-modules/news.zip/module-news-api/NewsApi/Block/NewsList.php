<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApi\Block;

use Hibrido\NewsApi\Api\Data\Article;
use Hibrido\NewsApi\Api\NewsApiConnector;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Serialize\Serializer\Json;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;

class NewsList extends Template
{
    public function __construct(
        protected Context $context,
        private readonly NewsApiConnector $connector,
        private readonly Json $jsonSerializer,
        protected array $data = []
    ) {
        parent::__construct($context, $data);
    }

    /**
     * @return Article[]
     * @throws LocalizedException
     */
    public function getNews(): array
    {
        return $this->connector->execute();
    }

    /**
     * @throws LocalizedException
     */
    public function getNewsJsonData(): string
    {
        $news = array_map(function (Article $article) {
            return [
                'title' => $article->getTitle(),
                'url' => $article->getUrl(),
                'image' => $article->getImage(),
                'description' => $article->getDescription()
            ];
        }, $this->getNews());

        return $this->jsonSerializer->serialize($news);
    }
}
