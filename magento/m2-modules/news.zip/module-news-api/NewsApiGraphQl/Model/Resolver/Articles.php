<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApiGraphQl\Model\Resolver;

use Hibrido\NewsApiGraphQl\Model\Resolver\DataProvider\Articles as ArticlesDataProvider;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\GraphQl\Config\Element\Field;
use Magento\Framework\GraphQl\Exception\GraphQlNoSuchEntityException;
use Magento\Framework\GraphQl\Query\ResolverInterface;
use Magento\Framework\GraphQl\Schema\Type\ResolveInfo;

class Articles implements ResolverInterface
{
    private ArticlesDataProvider $articlesDataProvider;

    /**
     * @param ArticlesDataProvider $articlesDataProvider
     */
    public function __construct(
        ArticlesDataProvider $articlesDataProvider
    ) {
        $this->articlesDataProvider = $articlesDataProvider;
    }

    /**
     * @inheritdoc
     */
    public function resolve(
        Field $field,
        $context,
        ResolveInfo $info,
        array $value = null,
        array $args = null
    ) {
        $title = $args['title'] ?? '';

        try {
            $articlesData = $this->articlesDataProvider->getAllArticles($title);
        } catch (LocalizedException $e) {
            throw new GraphQlNoSuchEntityException(__($e->getMessage()), $e);
        }

        return $articlesData;
    }
}
