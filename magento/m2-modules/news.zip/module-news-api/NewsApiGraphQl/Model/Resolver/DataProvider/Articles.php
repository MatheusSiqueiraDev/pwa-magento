<?php
/**
 * Copyright © Hibrido. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Hibrido\NewsApiGraphQl\Model\Resolver\DataProvider;

use Hibrido\NewsApi\Api\Data\Article;
use Hibrido\NewsApi\Api\NewsApiConnector;
use Magento\Framework\Exception\LocalizedException;

class Articles
{
    /**
     * @var NewsApiConnector
     */
    private NewsApiConnector $connector;

    /**
     * @param NewsApiConnector $connector
     */
    public function __construct(
        NewsApiConnector $connector
    ) {
        $this->connector = $connector;
    }

    /**
     * @param string $title
     * @return array
     * @throws LocalizedException
     */
    public function getAllArticles(string $title = ''): array
    {
        $articles = $this->connector->execute();

        if (!empty($title)) {
            $articles = array_filter($articles, function (Article $article) use ($title) {
                return stristr($article->getTitle(), $title);
            });
        }

        return array_map(function (Article $article) {
            return [
                'url' => $article->getUrl(),
                'title' => $article->getTitle(),
                'image' => $article->getImage(),
                'description' => $article->getDescription()
            ];
        }, $articles);
    }
}
